//
//  coursework2App.swift
//  Shared
//
//  Created by Cosmin Stefanescu on 15/05/2022.
//

import SwiftUI

@main
struct coursework2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
