//
//  ForecastModel.swift
//  coursework2 (iOS)
//
//  Created by Cosmin Stefanescu on 15/05/2022.
//

import Foundation

