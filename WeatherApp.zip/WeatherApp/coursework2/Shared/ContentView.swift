//
//  ContentView.swift
//  Shared
//
//  Created by Cosmin Stefanescu on 15/05/2022.
//

import SwiftUI

struct ContentView: View {
    @State var cityName: String = ""
    @State var weatherForView: Weather?
    @State var tempAsString: String=""
    var body: some View {
        ZStack{
            Image("screenBackground").resizable().ignoresSafeArea()
            TabView{
                VStack{
                    //Search view
                    TextField("City name...", text:$cityName, onEditingChanged: {_ in
                            getWeather(cityName: formatCityName(cityName: cityName))
                        
                    }).textFieldStyle(RoundedBorderTextFieldStyle())
                        .multilineTextAlignment(.center)
                    HStack{
                        Image("temp").resizable()
                            .frame(width: 32.0, height: 32.0)
                            .scaledToFit()
                        Text(formatTemp(temp: weatherForView?.main.temp.description ?? ""))
                    }
                    HStack{
                        Image("humidity").resizable()
                            .frame(width: 32.0, height: 32.0)
                            .scaledToFit()
                        Text(formatHumidity(humidity: weatherForView?.main.humidity.description ?? ""))
                    }
                }.tabItem{
                    Text("Search")
                }
                VStack{
                    //WeatherDetailView
                    HStack{
                        Text("Weather in ")
                        Text (cityName)
                    }
                    HStack{
                        Image("temp").resizable()
                            .frame(width: 32.0, height: 32.0)
                            .scaledToFit()
                        Text(formatTemp(temp: weatherForView?.main.temp.description ?? ""))
                    }
                    HStack{
                        Image("humidity").resizable()
                            .frame(width: 32.0, height: 32.0)
                            .scaledToFit()
                        Text(formatHumidity(humidity: weatherForView?.main.humidity.description ?? ""))
                    }
                    HStack{
                        Image("pressure").resizable()
                            .frame(width: 32.0, height: 32.0)
                            .scaledToFit()
                        Text( weatherForView?.main.pressure.description ?? "")
                    }
                    HStack{
                        Image("windSpeed").resizable()
                            .frame(width: 32.0, height: 32.0)
                            .scaledToFit()
                        Text( weatherForView?.wind.speed.description ?? "")
                    }
                    
                
                }.tabItem{
                    Text("Detailed weather")
                }
                VStack{
                    //Forecast View
                }.tabItem{
                    Text("5 Day Weather")
                }
            }
        }
        
    }
    func getWeather(cityName: String){
        let url = setLocationURLString(location: cityName)
        getCurrentWeather(url: url, completion: {_ in weatherForView = weather})
    }
    
    //formatting the temperature to display it with the "C" symbol
    func formatTemp(temp: String) -> String {
            if(!temp.isEmpty){
                return temp+" C"
            }
            else {
                return "Temperature"
        }
    }
    
    //formatting the humidity to display it with the "%" symbol
    func formatHumidity(humidity: String) -> String {
            if(!humidity.isEmpty){
                return humidity + "%"
            }
            else {
                return "Humidity"
        }
    }
    
    //formatting the user input
    func formatCityName(cityName: String) -> String{
        let cityNameArr = cityName.components(separatedBy: " ")
        var formattedCityName : String = ""
        for i in 0...cityNameArr.count-1{
            formattedCityName = formattedCityName + cityNameArr[i]+"+"
        }
        formattedCityName.removeLast()
        return formattedCityName
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
